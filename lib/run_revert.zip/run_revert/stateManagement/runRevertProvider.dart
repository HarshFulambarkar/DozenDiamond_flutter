import 'package:dozen_diamond/run_revert/model/fetch_run_id_response.dart';
import 'package:dozen_diamond/run_revert/model/revert_run_id_request.dart';
import 'package:dozen_diamond/run_revert/service/runRevertService.dart';
import 'package:flutter/material.dart';

class RunRevertProvider extends ChangeNotifier {
  int _selectedRunId = -1;

  int get selectedRunId => _selectedRunId;

  set selectedRunId(int value) {
    _selectedRunId = value;
    notifyListeners();
  }

  List<RecentRun> _revertRunData = [];

  List<RecentRun> get revertRunData => _revertRunData;

  set revertRunData(List<RecentRun> value) {
    _revertRunData = value;
    notifyListeners();
  }

  FetchRunIdResponse _fetchRunIdResponse = FetchRunIdResponse();

  FetchRunIdResponse get fetchRunIdResponse => _fetchRunIdResponse;

  set fetchRunIdResponse(FetchRunIdResponse value) {
    _fetchRunIdResponse = value;
    notifyListeners();
  }

  Future<void> getAllRunOfAUser() async {
    try {
      print("heelo from the ln 9");
      _fetchRunIdResponse = await RunRevertService().getAllRunOfAUser();

      notifyListeners();
    } catch (e) {
      throw e;
    }
  }

  Future<void> revertRunIdOfAUser() async {
    try {
      await RunRevertService()
          .revertTheRunIdOfAUser(RevertRunIdRequest(runId: selectedRunId));
    } catch (e) {
      throw e;
    }
  }
}
